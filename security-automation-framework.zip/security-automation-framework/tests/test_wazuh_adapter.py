import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from wazuh_adapter import convert, level_to_severity, is_public_ip, load_wazuh_alerts

SAMPLE = os.path.join(os.path.dirname(__file__), "..", "data", "wazuh_alerts_sample.json")


def test_severity_mapping():
    assert level_to_severity(3) == "low"
    assert level_to_severity(5) == "medium"
    assert level_to_severity(10) == "high"
    assert level_to_severity(12) == "critical"


def test_public_vs_private_ip():
    assert is_public_ip("8.8.8.8")
    assert not is_public_ip("10.0.2.4")
    assert not is_public_ip("not-an-ip")


def test_low_level_noise_filtered():
    alerts = load_wazuh_alerts(SAMPLE, min_level=5)
    assert len(alerts) == 3
    assert all(a["severity"] == "medium" for a in alerts)


def test_local_su_alerts_have_no_indicator():
    for a in load_wazuh_alerts(SAMPLE):
        assert a["indicators"] == []


def test_public_srcip_becomes_indicator():
    synthetic = {  # synthetic alert, for testing only
        "id": "T-1", "timestamp": "2026-09-28T00:00:00+0000",
        "rule": {"level": 5, "description": "sshd: authentication failed.", "id": "5760"},
        "agent": {"name": "project-vm"}, "data": {"srcip": "8.8.8.8"},
    }
    assert convert(synthetic)["indicators"] == [{"type": "ip", "value": "8.8.8.8"}]
