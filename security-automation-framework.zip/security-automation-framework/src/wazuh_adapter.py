"""Convert Wazuh alerts.json (JSON Lines) into the framework's alert format."""
import ipaddress
import json
import sys


def level_to_severity(level):
    if level >= 12:
        return "critical"
    if level >= 8:
        return "high"
    if level >= 5:
        return "medium"
    return "low"


def is_public_ip(value):
    try:
        return ipaddress.ip_address(value).is_global
    except ValueError:
        return False


def convert(wazuh_alert):
    data = wazuh_alert.get("data", {})
    indicators = []
    srcip = data.get("srcip")
    if srcip and is_public_ip(srcip):
        indicators.append({"type": "ip", "value": srcip})

    rule = wazuh_alert["rule"]
    return {
        "alert_id": wazuh_alert["id"],
        "timestamp": wazuh_alert["timestamp"],
        "source": wazuh_alert["agent"]["name"],
        "alert_type": rule["description"],
        "severity": level_to_severity(rule["level"]),
        "rule_id": rule["id"],
        "mitre": rule.get("mitre", {}).get("id", []),
        "indicators": indicators,
    }


def load_wazuh_alerts(path, min_level=5):
    """alerts.json holds one JSON object per line, not a JSON array."""
    alerts = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
                if raw["rule"]["level"] >= min_level:
                    alerts.append(convert(raw))
            except (json.JSONDecodeError, KeyError):
                continue  # skip malformed lines
    return alerts


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "data/wazuh_alerts_sample.json"
    for alert in load_wazuh_alerts(path):
        print(json.dumps(alert, indent=2))
