# Wazuh Setup and Validation (Phase 1: completed)

## Environment
- Wazuh Manager: cloud VM (Ubuntu)
- Wazuh Agent: Kali Linux VM (`project-vm`) reporting to the manager

## Validation performed
1. Agent registered and shows **Active** in the Wazuh dashboard.
2. Generated failed authentication events with `su` using a wrong password.
3. Confirmed alerts in `/var/ossec/logs/alerts/alerts.json`:

| Rule ID | Level | Description | MITRE |
|---|---|---|---|
| 5301 | 5 | User missed the password to change UID | - |
| 5503 | 5 | PAM: User login failed | T1110.001 Password Guessing |
| 5557 | 5 | unix_chkpwd: Password check failed | T1110.001 Password Guessing |
| 5402 | 3 | Successful sudo to ROOT | T1548.003 (noise, filtered) |

Command used to watch alerts live:
```bash
sudo tail -f /var/ossec/logs/alerts/alerts.json
```

## Findings
- Local `su` failures have no `srcip`, so they have no external indicator for enrichment.
- Level 3 alerts (own sudo usage) are noise and are filtered by the adapter (`min_level=5`).
- `alerts.json` is JSON Lines, so it must be parsed line by line.

Add screenshots to `/screenshots` (agent Active, alerts in dashboard, terminal output).
